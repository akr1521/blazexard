package com.blazecard.Blazecard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlazecardApplication {

	public static void main(String[] args) {
		SpringApplication.run(BlazecardApplication.class, args);
	}

}
