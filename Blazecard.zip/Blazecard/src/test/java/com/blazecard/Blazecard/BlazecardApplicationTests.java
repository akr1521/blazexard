package com.blazecard.Blazecard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlazecardApplicationTests {

	@Test
	void contextLoads() {
	}

}
